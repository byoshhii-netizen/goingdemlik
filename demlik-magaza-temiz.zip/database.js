﻿const { Pool } = require('pg');
const crypto = require('crypto');

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.DATABASE_URL && process.env.DATABASE_URL.includes('railway')
    ? { rejectUnauthorized: false }
    : false,
});

async function query(text, params) {
  const client = await pool.connect();
  try {
    return await client.query(text, params);
  } finally {
    client.release();
  }
}

async function initDb() {
  await query(`
    CREATE TABLE IF NOT EXISTS users (
      id BIGSERIAL PRIMARY KEY,
      username TEXT UNIQUE NOT NULL,
      email TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      avatar TEXT DEFAULT '',
      bio TEXT DEFAULT '',
      links TEXT DEFAULT '[]',
      level_id INTEGER DEFAULT 1,
      show_level_badge INTEGER DEFAULT 1,
      show_level_color INTEGER DEFAULT 1,
      is_vip INTEGER DEFAULT 0,
      is_plus INTEGER DEFAULT 0,
      name_color TEXT DEFAULT '',
      banned INTEGER DEFAULT 0,
      ban_type TEXT DEFAULT '',
      banned_ip TEXT DEFAULT '',
      ip TEXT DEFAULT '',
      kvkk_accepted INTEGER DEFAULT 0,
      forum_count INTEGER DEFAULT 0,
      book_count INTEGER DEFAULT 0,
      comment_count INTEGER DEFAULT 0,
      created_at TIMESTAMP DEFAULT NOW(),
      last_active TIMESTAMP DEFAULT NOW()
    );

    CREATE TABLE IF NOT EXISTS sessions (
      token TEXT PRIMARY KEY,
      user_id BIGINT NOT NULL,
      created_at TIMESTAMP DEFAULT NOW()
    );

    CREATE TABLE IF NOT EXISTS levels (
      id BIGSERIAL PRIMARY KEY,
      name TEXT NOT NULL,
      icon TEXT DEFAULT 'fas fa-star',
      color TEXT DEFAULT '#dc2626',
      min_forums INTEGER DEFAULT 0,
      min_books INTEGER DEFAULT 0,
      min_comments INTEGER DEFAULT 0,
      min_book_pages INTEGER DEFAULT 0,
      require_any INTEGER DEFAULT 0,
      order_num INTEGER DEFAULT 0,
      daily_forums INTEGER DEFAULT -1,
      daily_books INTEGER DEFAULT -1,
      daily_book_pages INTEGER DEFAULT -1,
      daily_forums_vip INTEGER DEFAULT -1,
      daily_books_vip INTEGER DEFAULT -1,
      daily_book_pages_vip INTEGER DEFAULT -1,
      daily_forums_plus INTEGER DEFAULT -1,
      daily_books_plus INTEGER DEFAULT -1,
      daily_book_pages_plus INTEGER DEFAULT -1
    );

    CREATE TABLE IF NOT EXISTS settings (
      key TEXT PRIMARY KEY,
      value TEXT
    );

    CREATE TABLE IF NOT EXISTS store_products (
      id BIGSERIAL PRIMARY KEY,
      product_key TEXT UNIQUE NOT NULL,
      title TEXT NOT NULL,
      description TEXT DEFAULT '',
      features TEXT DEFAULT '[]',
      price NUMERIC(12,2) NOT NULL DEFAULT 0,
      compare_at_price NUMERIC(12,2),
      currency TEXT NOT NULL DEFAULT 'TRY',
      active INTEGER DEFAULT 1,
      visible INTEGER DEFAULT 1,
      shopier_product_id TEXT DEFAULT '',
      created_at TIMESTAMP DEFAULT NOW(),
      updated_at TIMESTAMP DEFAULT NOW()
    );

    CREATE TABLE IF NOT EXISTS store_orders (
      id BIGSERIAL PRIMARY KEY,
      user_id BIGINT NOT NULL,
      product_id BIGINT NOT NULL,
      merchant_order_id TEXT UNIQUE NOT NULL,
      shopier_product_id TEXT DEFAULT '',
      shopier_order_id TEXT UNIQUE,
      amount NUMERIC(12,2) NOT NULL,
      currency TEXT NOT NULL DEFAULT 'TRY',
      status TEXT NOT NULL DEFAULT 'pending',
      webhook_id TEXT DEFAULT '',
      raw_payload JSONB DEFAULT '{}',
      created_at TIMESTAMP DEFAULT NOW(),
      paid_at TIMESTAMP,
      FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
      FOREIGN KEY(product_id) REFERENCES store_products(id) ON DELETE RESTRICT
    );

    CREATE TABLE IF NOT EXISTS store_entitlements (
      id BIGSERIAL PRIMARY KEY,
      user_id BIGINT NOT NULL,
      product_id BIGINT NOT NULL,
      order_id BIGINT NOT NULL,
      entitlement_type TEXT NOT NULL,
      starts_at TIMESTAMP NOT NULL DEFAULT NOW(),
      expires_at TIMESTAMP NOT NULL,
      revoked_at TIMESTAMP,
      created_at TIMESTAMP DEFAULT NOW(),
      UNIQUE(order_id, entitlement_type),
      FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
      FOREIGN KEY(product_id) REFERENCES store_products(id) ON DELETE RESTRICT,
      FOREIGN KEY(order_id) REFERENCES store_orders(id) ON DELETE CASCADE
    );

    CREATE INDEX IF NOT EXISTS idx_store_orders_user ON store_orders(user_id, created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_store_entitlements_user ON store_entitlements(user_id, entitlement_type, expires_at);

    CREATE TABLE IF NOT EXISTS forums (
      id BIGSERIAL PRIMARY KEY,
      user_id BIGINT,
      title TEXT NOT NULL,
      content TEXT NOT NULL,
      banner_image TEXT DEFAULT '',
      slug TEXT UNIQUE,
      allow_comments INTEGER DEFAULT 1,
      custom_tags TEXT DEFAULT '',
      views INTEGER DEFAULT 0,
      created_at TIMESTAMP DEFAULT NOW(),
      updated_at TIMESTAMP DEFAULT NOW(),
      FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL
    );

    CREATE TABLE IF NOT EXISTS forum_views (
      id BIGSERIAL PRIMARY KEY,
      forum_id BIGINT,
      ip TEXT,
      view_count INTEGER DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS forum_likes (
      id BIGSERIAL PRIMARY KEY,
      forum_id BIGINT,
      user_id BIGINT,
      UNIQUE(forum_id, user_id)
    );

    CREATE TABLE IF NOT EXISTS forum_comments (
      id BIGSERIAL PRIMARY KEY,
      forum_id BIGINT,
      user_id BIGINT,
      content TEXT NOT NULL,
      created_at TIMESTAMP DEFAULT NOW(),
      FOREIGN KEY(forum_id) REFERENCES forums(id) ON DELETE CASCADE,
      FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL
    );

    CREATE TABLE IF NOT EXISTS forum_comment_likes (
      id BIGSERIAL PRIMARY KEY,
      comment_id BIGINT,
      user_id BIGINT,
      UNIQUE(comment_id, user_id),
      FOREIGN KEY(comment_id) REFERENCES forum_comments(id) ON DELETE CASCADE,
      FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS tags (
      id BIGSERIAL PRIMARY KEY,
      name TEXT UNIQUE NOT NULL,
      color TEXT DEFAULT '#dc2626',
      is_system INTEGER DEFAULT 1
    );

    CREATE TABLE IF NOT EXISTS forum_tags (
      id BIGSERIAL PRIMARY KEY,
      forum_id BIGINT,
      tag_id BIGINT,
      UNIQUE(forum_id, tag_id),
      FOREIGN KEY(forum_id) REFERENCES forums(id) ON DELETE CASCADE,
      FOREIGN KEY(tag_id) REFERENCES tags(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS books (
      id BIGSERIAL PRIMARY KEY,
      user_id BIGINT,
      title TEXT NOT NULL,
      preface TEXT DEFAULT '',
      karakterler TEXT DEFAULT '',
      kadro TEXT DEFAULT '',
      cover_image TEXT DEFAULT '',
      slug TEXT UNIQUE,
      page_count INTEGER DEFAULT 0,
      is_hidden INTEGER DEFAULT 0,
      created_at TIMESTAMP DEFAULT NOW(),
      updated_at TIMESTAMP DEFAULT NOW(),
      FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL
    );

    ALTER TABLE books ADD COLUMN IF NOT EXISTS karakterler TEXT DEFAULT '';
    ALTER TABLE books ADD COLUMN IF NOT EXISTS kadro TEXT DEFAULT '';
    ALTER TABLE books ADD COLUMN IF NOT EXISTS is_hidden INTEGER DEFAULT 0;

    CREATE TABLE IF NOT EXISTS book_chapters (
      id BIGSERIAL PRIMARY KEY,
      book_id BIGINT,
      title TEXT NOT NULL,
      order_num INTEGER DEFAULT 0,
      FOREIGN KEY(book_id) REFERENCES books(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS book_pages (
      id BIGSERIAL PRIMARY KEY,
      book_id BIGINT,
      chapter_id BIGINT,
      title TEXT NOT NULL,
      content TEXT NOT NULL,
      page_num INTEGER DEFAULT 1,
      slug TEXT UNIQUE,
      image_url TEXT DEFAULT '',
      created_at TIMESTAMP DEFAULT NOW(),
      FOREIGN KEY(book_id) REFERENCES books(id) ON DELETE CASCADE,
      FOREIGN KEY(chapter_id) REFERENCES book_chapters(id) ON DELETE SET NULL
    );

    CREATE TABLE IF NOT EXISTS groups (
      id BIGSERIAL PRIMARY KEY,
      name TEXT NOT NULL,
      slug TEXT UNIQUE,
      description TEXT DEFAULT '',
      cover_image TEXT DEFAULT '',
      owner_id BIGINT,
      type TEXT DEFAULT 'public',
      allow_chat INTEGER DEFAULT 1,
      allow_photos INTEGER DEFAULT 1,
      invite_only INTEGER DEFAULT 0,
      member_count INTEGER DEFAULT 0,
      created_at TIMESTAMP DEFAULT NOW(),
      FOREIGN KEY(owner_id) REFERENCES users(id) ON DELETE SET NULL
    );

    CREATE TABLE IF NOT EXISTS group_members (
      id BIGSERIAL PRIMARY KEY,
      group_id BIGINT,
      user_id BIGINT,
      role TEXT DEFAULT 'member',
      joined_at TIMESTAMP DEFAULT NOW(),
      UNIQUE(group_id, user_id),
      FOREIGN KEY(group_id) REFERENCES groups(id) ON DELETE CASCADE,
      FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS group_join_requests (
      id BIGSERIAL PRIMARY KEY,
      group_id BIGINT,
      user_id BIGINT,
      status TEXT DEFAULT 'pending',
      rejection_reason TEXT DEFAULT '',
      created_at TIMESTAMP DEFAULT NOW(),
      reviewed_at TIMESTAMP,
      reviewed_by BIGINT,
      UNIQUE(group_id, user_id),
      FOREIGN KEY(group_id) REFERENCES groups(id) ON DELETE CASCADE,
      FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
      FOREIGN KEY(reviewed_by) REFERENCES users(id) ON DELETE SET NULL
    );

    CREATE TABLE IF NOT EXISTS moderator_permissions (
      id BIGSERIAL PRIMARY KEY,
      group_id BIGINT,
      user_id BIGINT,
      can_delete_messages INTEGER DEFAULT 0,
      can_ban_members INTEGER DEFAULT 0,
      can_edit_group INTEGER DEFAULT 0,
      can_manage_invites INTEGER DEFAULT 0,
      UNIQUE(group_id, user_id)
    );

    CREATE TABLE IF NOT EXISTS group_messages (
      id BIGSERIAL PRIMARY KEY,
      group_id BIGINT,
      user_id BIGINT,
      content TEXT,
      image_url TEXT DEFAULT '',
      created_at TIMESTAMP DEFAULT NOW(),
      FOREIGN KEY(group_id) REFERENCES groups(id) ON DELETE CASCADE,
      FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL
    );

    CREATE TABLE IF NOT EXISTS group_invites (
      id BIGSERIAL PRIMARY KEY,
      group_id BIGINT,
      invite_code TEXT UNIQUE,
      created_by BIGINT,
      created_at TIMESTAMP DEFAULT NOW()
    );

    CREATE TABLE IF NOT EXISTS photos (
      id BIGSERIAL PRIMARY KEY,
      user_id BIGINT NOT NULL,
      url TEXT NOT NULL,
      caption TEXT DEFAULT '',
      created_at TIMESTAMP DEFAULT NOW(),
      FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    );
      CREATE TABLE IF NOT EXISTS photo_likes (
        id BIGSERIAL PRIMARY KEY,
        photo_id BIGINT NOT NULL,
        user_id BIGINT NOT NULL,
        created_at TIMESTAMP DEFAULT NOW(),
        UNIQUE(photo_id, user_id),
        FOREIGN KEY(photo_id) REFERENCES photos(id) ON DELETE CASCADE,
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
      );

      CREATE TABLE IF NOT EXISTS photo_comments (
        id BIGSERIAL PRIMARY KEY,
        photo_id BIGINT NOT NULL,
        user_id BIGINT,
        content TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT NOW(),
        FOREIGN KEY(photo_id) REFERENCES photos(id) ON DELETE CASCADE,
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL
      );

      CREATE TABLE IF NOT EXISTS badges (
        id BIGSERIAL PRIMARY KEY,
        name TEXT NOT NULL,
        icon TEXT DEFAULT '',
        color TEXT DEFAULT '#6b7280',
        created_at TIMESTAMP DEFAULT NOW()
      );

      CREATE TABLE IF NOT EXISTS gifts (
        id BIGSERIAL PRIMARY KEY,
        code TEXT UNIQUE NOT NULL,
        sender_id BIGINT NOT NULL,
        recipient_id BIGINT,
        recipient_username TEXT DEFAULT '',
        type TEXT NOT NULL,
        redeemed INTEGER DEFAULT 0,
        redeemed_at TIMESTAMP,
        created_at TIMESTAMP DEFAULT NOW(),
        FOREIGN KEY(sender_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY(recipient_id) REFERENCES users(id) ON DELETE SET NULL
      );

    CREATE TABLE IF NOT EXISTS system_logs (
      id BIGSERIAL PRIMARY KEY,
      actor TEXT,
      action TEXT,
      target TEXT DEFAULT '',
      detail TEXT DEFAULT '',
      ip TEXT DEFAULT '',
      created_at TIMESTAMP DEFAULT NOW()
    );

    CREATE TABLE IF NOT EXISTS friendships (
      id BIGSERIAL PRIMARY KEY,
      requester_id BIGINT NOT NULL,
      addressee_id BIGINT NOT NULL,
      status TEXT DEFAULT 'pending',
      created_at TIMESTAMP DEFAULT NOW(),
      updated_at TIMESTAMP DEFAULT NOW(),
      UNIQUE(requester_id, addressee_id),
      FOREIGN KEY(requester_id) REFERENCES users(id) ON DELETE CASCADE,
      FOREIGN KEY(addressee_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS blocks (
      id BIGSERIAL PRIMARY KEY,
      blocker_id BIGINT NOT NULL,
      blocked_id BIGINT NOT NULL,
      created_at TIMESTAMP DEFAULT NOW(),
      UNIQUE(blocker_id, blocked_id),
      FOREIGN KEY(blocker_id) REFERENCES users(id) ON DELETE CASCADE,
      FOREIGN KEY(blocked_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS dm_conversations (
      id BIGSERIAL PRIMARY KEY,
      user1_id BIGINT NOT NULL,
      user2_id BIGINT NOT NULL,
      hidden_by_user1 INTEGER DEFAULT 0,
      hidden_by_user2 INTEGER DEFAULT 0,
      hidden_pass_user1 TEXT DEFAULT '',
      hidden_pass_user2 TEXT DEFAULT '',
      last_message_at TIMESTAMP DEFAULT NOW(),
      created_at TIMESTAMP DEFAULT NOW(),
      UNIQUE(user1_id, user2_id),
      FOREIGN KEY(user1_id) REFERENCES users(id) ON DELETE CASCADE,
      FOREIGN KEY(user2_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS videos (
      id BIGSERIAL PRIMARY KEY,
      user_id BIGINT NOT NULL,
      title TEXT NOT NULL,
      description TEXT DEFAULT '',
      video_url TEXT NOT NULL,
      thumbnail_url TEXT DEFAULT '',
      slug TEXT UNIQUE,
      views INTEGER DEFAULT 0,
      created_at TIMESTAMP DEFAULT NOW(),
      FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL
    );

    CREATE TABLE IF NOT EXISTS dm_messages (
      id BIGSERIAL PRIMARY KEY,
      conversation_id BIGINT NOT NULL,
      sender_id BIGINT NOT NULL,
      content TEXT DEFAULT '',
      image_url TEXT DEFAULT '',
      shared_forum_id BIGINT,
      shared_video_id BIGINT,
      reply_to_id BIGINT,
      deleted_by_sender INTEGER DEFAULT 0,
      deleted_by_receiver INTEGER DEFAULT 0,
      deleted_for_all INTEGER DEFAULT 0,
      created_at TIMESTAMP DEFAULT NOW(),
      FOREIGN KEY(conversation_id) REFERENCES dm_conversations(id) ON DELETE CASCADE,
      FOREIGN KEY(sender_id) REFERENCES users(id) ON DELETE CASCADE,
      FOREIGN KEY(shared_forum_id) REFERENCES forums(id) ON DELETE SET NULL,
      FOREIGN KEY(shared_video_id) REFERENCES videos(id) ON DELETE SET NULL,
      FOREIGN KEY(reply_to_id) REFERENCES dm_messages(id) ON DELETE SET NULL
    );

    ALTER TABLE forums ADD COLUMN IF NOT EXISTS allow_sharing INTEGER DEFAULT 1;
    ALTER TABLE forums ADD COLUMN IF NOT EXISTS share_count INTEGER DEFAULT 0;
    ALTER TABLE dm_messages ADD COLUMN IF NOT EXISTS shared_video_id BIGINT;
    ALTER TABLE dm_conversations ADD COLUMN IF NOT EXISTS read_until_user1 BIGINT DEFAULT 0;
      ALTER TABLE photos ADD COLUMN IF NOT EXISTS show_likes INTEGER DEFAULT 1;
      ALTER TABLE photos ADD COLUMN IF NOT EXISTS allow_comments INTEGER DEFAULT 1;
      ALTER TABLE photos ADD COLUMN IF NOT EXISTS allow_shares INTEGER DEFAULT 1;
      ALTER TABLE photos ADD COLUMN IF NOT EXISTS like_count INTEGER DEFAULT 0;
      ALTER TABLE photos ADD COLUMN IF NOT EXISTS comment_count INTEGER DEFAULT 0;
      ALTER TABLE photos ADD COLUMN IF NOT EXISTS share_count INTEGER DEFAULT 0;
    ALTER TABLE dm_conversations ADD COLUMN IF NOT EXISTS read_until_user2 BIGINT DEFAULT 0;
    ALTER TABLE users ADD COLUMN IF NOT EXISTS is_admin INTEGER DEFAULT 0;
    ALTER TABLE users ADD COLUMN IF NOT EXISTS admin_since TIMESTAMP;
    ALTER TABLE users ADD COLUMN IF NOT EXISTS spotify_id TEXT DEFAULT '';
    ALTER TABLE users ADD COLUMN IF NOT EXISTS spotify_token TEXT DEFAULT '';
    ALTER TABLE users ADD COLUMN IF NOT EXISTS spotify_refresh TEXT DEFAULT '';
    ALTER TABLE users ADD COLUMN IF NOT EXISTS spotify_show INTEGER DEFAULT 1;
    ALTER TABLE users ADD COLUMN IF NOT EXISTS spotify_expires BIGINT DEFAULT 0;
    ALTER TABLE users ADD COLUMN IF NOT EXISTS title TEXT DEFAULT '';
    ALTER TABLE users ADD COLUMN IF NOT EXISTS location TEXT DEFAULT '';
    ALTER TABLE dm_messages ADD COLUMN IF NOT EXISTS read_at TIMESTAMP;

    CREATE TABLE IF NOT EXISTS announcements (
      id BIGSERIAL PRIMARY KEY,
      title TEXT NOT NULL,
      content TEXT NOT NULL,
      bg_color TEXT DEFAULT '#dc2626',
      text_color TEXT DEFAULT '#ffffff',
      border_color TEXT DEFAULT '#991b1b',
      position TEXT DEFAULT 'top',
      size TEXT DEFAULT 'normal',
      expires_at TIMESTAMP,
      active INTEGER DEFAULT 1,
      created_at TIMESTAMP DEFAULT NOW()
    );

    CREATE TABLE IF NOT EXISTS admin_permissions (
      id BIGSERIAL PRIMARY KEY,
      user_id BIGINT UNIQUE NOT NULL,
      can_ban_users INTEGER DEFAULT 0,
      can_delete_content INTEGER DEFAULT 0,
      can_edit_content INTEGER DEFAULT 0,
      can_manage_levels INTEGER DEFAULT 0,
      can_manage_tags INTEGER DEFAULT 0,
      can_manage_announcements INTEGER DEFAULT 0,
      can_view_logs INTEGER DEFAULT 0,
      can_manage_settings INTEGER DEFAULT 0,
      can_manage_admins INTEGER DEFAULT 0,
      can_view_users INTEGER DEFAULT 1,
      granted_by BIGINT,
      granted_at TIMESTAMP DEFAULT NOW(),
      FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    ALTER TABLE settings ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP DEFAULT NOW();
    ALTER TABLE users ADD COLUMN IF NOT EXISTS admin_permissions_id BIGINT;
    ALTER TABLE users ADD COLUMN IF NOT EXISTS is_artist INTEGER DEFAULT 0;
    ALTER TABLE users ADD COLUMN IF NOT EXISTS artist_since TIMESTAMP;
    ALTER TABLE users ADD COLUMN IF NOT EXISTS artist_display_name TEXT DEFAULT '';
    ALTER TABLE users ADD COLUMN IF NOT EXISTS artist_bio TEXT DEFAULT '';
    ALTER TABLE users ADD COLUMN IF NOT EXISTS artist_genre TEXT DEFAULT '';
    ALTER TABLE users ADD COLUMN IF NOT EXISTS artist_website TEXT DEFAULT '';
    ALTER TABLE users ADD COLUMN IF NOT EXISTS badge_name TEXT DEFAULT '';
    ALTER TABLE users ADD COLUMN IF NOT EXISTS badge_icon TEXT DEFAULT '';
    ALTER TABLE users ADD COLUMN IF NOT EXISTS badge_color TEXT DEFAULT '#6b7280';
    ALTER TABLE users ADD COLUMN IF NOT EXISTS badge_display TEXT DEFAULT 'level';
    ALTER TABLE users ADD COLUMN IF NOT EXISTS delete_requested_at TIMESTAMP;
    ALTER TABLE users ADD COLUMN IF NOT EXISTS is_deleted INTEGER DEFAULT 0;
    ALTER TABLE users ADD COLUMN IF NOT EXISTS allow_mentions INTEGER DEFAULT 1;
    ALTER TABLE forums ADD COLUMN IF NOT EXISTS banner_fit TEXT DEFAULT 'cover';
    ALTER TABLE forums ADD COLUMN IF NOT EXISTS images TEXT DEFAULT '[]';
    ALTER TABLE forums ADD COLUMN IF NOT EXISTS thumbnail TEXT DEFAULT '';
    ALTER TABLE users ADD COLUMN IF NOT EXISTS name_color_mode TEXT DEFAULT 'solid';
    ALTER TABLE users ADD COLUMN IF NOT EXISTS name_gradient TEXT DEFAULT '';
    ALTER TABLE users ADD COLUMN IF NOT EXISTS paid_vip INTEGER DEFAULT 0;
    ALTER TABLE users ADD COLUMN IF NOT EXISTS paid_plus INTEGER DEFAULT 0;
    ALTER TABLE users ADD COLUMN IF NOT EXISTS paid_admin INTEGER DEFAULT 0;

    CREATE TABLE IF NOT EXISTS notifications (
      id BIGSERIAL PRIMARY KEY,
      user_id BIGINT NOT NULL,
      type TEXT NOT NULL,
      actor_username TEXT DEFAULT '',
      actor_avatar TEXT DEFAULT '',
      title TEXT DEFAULT '',
      body TEXT DEFAULT '',
      link TEXT DEFAULT '',
      is_read INTEGER DEFAULT 0,
      created_at TIMESTAMP DEFAULT NOW(),
      FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS artist_applications (
      id BIGSERIAL PRIMARY KEY,
      user_id BIGINT NOT NULL,
      genre TEXT NOT NULL,
      sample_song_url TEXT NOT NULL,
      sample_song_file TEXT DEFAULT '',
      note TEXT DEFAULT '',
      status TEXT DEFAULT 'pending',
      reviewed_by BIGINT,
      reviewed_at TIMESTAMP,
      created_at TIMESTAMP DEFAULT NOW(),
      FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS songs (
      id BIGSERIAL PRIMARY KEY,
      uploader_id BIGINT NOT NULL,
      song_type TEXT NOT NULL DEFAULT 'own',
      title TEXT NOT NULL,
      artist_name TEXT NOT NULL,
      distributor TEXT DEFAULT '',
      genre TEXT DEFAULT '',
      lyrics TEXT DEFAULT '',
      cover_url TEXT DEFAULT '',
      audio_url TEXT NOT NULL,
      share_reason TEXT DEFAULT '',
      play_count INTEGER DEFAULT 0,
      slug TEXT UNIQUE,
      status TEXT DEFAULT 'active',
      published_at TIMESTAMP DEFAULT NOW(),
      created_at TIMESTAMP DEFAULT NOW(),
      FOREIGN KEY(uploader_id) REFERENCES users(id) ON DELETE SET NULL
    );

    ALTER TABLE songs ADD COLUMN IF NOT EXISTS ban_reason TEXT DEFAULT '';
    ALTER TABLE songs ADD COLUMN IF NOT EXISTS ban_until TIMESTAMP;
  `);

  const { rows: storeRows } = await query('SELECT COUNT(*) as c FROM store_products');
  if (parseInt(storeRows[0].c) === 0) {
    await query(
      `INSERT INTO store_products
        (product_key,title,description,features,price,compare_at_price,currency,active,visible)
       VALUES
        ('vip','VIP Üyelik','Demlik deneyimini daha güçlü ve kişisel hale getir.','["VIP rozeti ve profil görünümü","Özel isim rengi","VIP içerik ve günlük limitler"]',99.90,149.90,'TRY',1,1),
        ('plus','Plus Üyelik','Daha fazla kişiselleştirme ve daha yüksek limitler.','["Plus rozeti ve ayrıcalıkları","Gelişmiş isim gradyanı","Plus içerik ve günlük limitler"]',149.90,199.90,'TRY',1,1),
        ('admin','Admin Yetkisi','Demlik yönetim araçlarına 30 günlük erişim.','["Admin paneli erişimi","Topluluk yönetim araçları","30 gün boyunca aktif yetki"]',249.90,399.90,'TRY',1,1)`
    );
  }

  // Seed default levels
  const { rows: lvRows } = await query('SELECT COUNT(*) as c FROM levels');
  if (parseInt(lvRows[0].c) === 0) {
    const ins = 'INSERT INTO levels (name,icon,color,min_forums,min_books,min_comments,order_num) VALUES ($1,$2,$3,$4,$5,$6,$7)';
    await query(ins, ['Yeni Üye',   'fas fa-seedling', '#6b7280', 0,  0,  0,   1]);
    await query(ins, ['Aktif Üye',  'fas fa-fire',     '#f97316', 5,  1,  10,  2]);
    await query(ins, ['Katkıcı',    'fas fa-pen',      '#3b82f6', 15, 3,  30,  3]);
    await query(ins, ['Uzman',      'fas fa-crown',    '#8b5cf6', 30, 5,  60,  4]);
    await query(ins, ['Efsane',     'fas fa-dragon',   '#dc2626', 50, 10, 100, 5]);
  }

  // Seed default tags
  const { rows: tagRows } = await query('SELECT COUNT(*) as c FROM tags');
  if (parseInt(tagRows[0].c) === 0) {
    const ins = 'INSERT INTO tags (name,color,is_system) VALUES ($1,$2,1)';
    await query(ins, ['Genel',     '#3b82f6']);
    await query(ins, ['Soru',      '#f97316']);
    await query(ins, ['Tartışma',  '#8b5cf6']);
    await query(ins, ['Haber',     '#dc2626']);
    await query(ins, ['Yardım',    '#10b981']);
    await query(ins, ['Teknoloji', '#06b6d4']);
    await query(ins, ['Sanat',     '#ec4899']);
    await query(ins, ['Edebiyat',  '#6366f1']);
  }

  // Seed admin password
  const { rows: pwRows } = await query("SELECT value FROM settings WHERE key='admin_password'");
  if (pwRows.length === 0) {
    const hash = crypto.createHash('sha256').update('admin123').digest('hex');
    await query('INSERT INTO settings (key,value) VALUES ($1,$2)', ['admin_password', hash]);
  }

  // Seed KVKK
  const { rows: kvkkRows } = await query("SELECT value FROM settings WHERE key='kvkk_text'");
  if (kvkkRows.length === 0) {
    await query('INSERT INTO settings (key,value) VALUES ($1,$2)', ['kvkk_text', `KİŞİSEL VERİLERİN KORUNMASI KANUNU (KVKK) AYDINLATMA METNİ

TeaTube olarak, 6698 sayılı Kişisel Verilerin Korunması Kanunu kapsamında kişisel verilerinizin işlenmesine ilişkin sizi bilgilendirmek isteriz.

1. VERİ SORUMLUSU
TeaTube platformu, veri sorumlusu sıfatıyla hareket etmektedir.

2. İŞLENEN KİŞİSEL VERİLER
Kullanıcı adı, e-posta adresi, IP adresi, platform içi içerikleriniz (forum gönderileri, kitap sayfaları, grup mesajları) işlenmektedir.

3. KİŞİSEL VERİLERİN İŞLENME AMACI
Kişisel verileriniz; platform hizmetlerinin sunulması, hesap yönetimi, güvenlik ve sahteciliğin önlenmesi amacıyla işlenmektedir.

4. KİŞİSEL VERİLERİN AKTARILMASI
Kişisel verileriniz yasal yükümlülükler dışında üçüncü kişilerle paylaşılmamaktadır.

5. HAKLARINIZ
KVKK'nın 11. maddesi kapsamında; kişisel verilerinize erişim, düzeltme, silme ve işlemenin kısıtlanmasını talep etme haklarına sahipsiniz.

6. İLETİŞİM
Talepleriniz için platform üzerinden iletişime geçebilirsiniz.`]);
  }

  console.log('PostgreSQL bağlantısı ve tablolar hazır.');
}

module.exports = { query, pool, initDb };
